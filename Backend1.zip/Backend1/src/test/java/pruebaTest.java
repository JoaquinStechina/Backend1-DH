import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class pruebaTest {

    @Test
    void getNombre() {
        var Test1 = new prueba();

        var aux = "Mauro";

        assertEquals(aux,Test1.getNombre()); //Sirve para verificar que dos cosas sean iguales
    }

    @Test
    void getEdad() {
        var Test2 = new prueba();

        var aux = 13;

        assertNotEquals(aux,Test2.getEdad());//Sirve para verificar que dos cosas NO sean iguales
    }

    @Test
    void setEdad() {
        var Test3 = new prueba();

        Integer aux = 52;
        Test3.setEdad(52);

        assertEquals(aux,Test3.getEdad());
    }
}