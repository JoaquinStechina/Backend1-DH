public class prueba {
    private final String nombre = "Mauro";
    private Integer edad = 24;

    public prueba() {
    }

    public String getNombre() {
        return nombre;
    }

    public Integer getEdad() {
        return edad;
    }

    public void setEdad(Integer edad) {
        this.edad = edad;
    }
}
